<footer class="footer footer-default">
    <div class="container">
        <nav class="float-left">
            <?php social_links(); ?>
        </nav>
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>
            <a class="text-secondary" href="<?php echo $config["url"]; ?>"><?php echo $config["title"]; ?></a>
        </div>
    </div>
</footer>
<script src="<?php echo $config["url"]; ?>/template/material/js/compressed.js" type="text/javascript"></script>
<script src="<?php echo $config["url"]; ?>/template/material/js/main.js" type="text/javascript"></script>
<?php
option("tracking_code", true);
option("gdpr_notice", true);
if (!empty($recaptcha_public_key)) {
    printf('<script src="https://www.google.com/recaptcha/api.js?render=%s"></script>', $recaptcha_public_key);
    printf("<script>%s</script>", str_replace('%s', $recaptcha_public_key, file_get_contents(__DIR__ . '/js/captcha.js')));
}
?>
</body>
</html>