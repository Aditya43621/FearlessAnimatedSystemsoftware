<?php
/*
 * Contributed by: tanweralam
 * Translate only right side.
 * Don't delete quotes and semicolon.
 */
$lang["rtl"] = true;
$lang["404-not-found"] = "404 صفحہ نہیں ملا";
$lang["go-home"] = "ہوم پیج پر جائیں";
$lang["terms-of-service"] = "سروس کی شرائط";
$lang["contact"] = "رابطہ کریں";
$lang["language"] = "زبان";
$lang["supported-sites"] = "تائید شدہ ویب سائٹس";
$lang["home"] = "ہوم";
$lang["close"] = "بند کریں";
$lang["follow-us"] = "ہمیں فالو کریں";
$lang["share"] = "بانٹیں";
$lang["download"] = "ڈاؤن لوڈ کریں";
$lang["downloader"] = "ڈاؤنلوڈر";
$lang["downloads"] = "ڈاؤن لوڈ";
$lang["video-downloader"] = "ویڈیو ڈاؤنلوڈر";
$lang["details"] = "ویڈیو کی تفصیلات";
$lang["duration"] = "دورانیہ";
$lang["preview"] = "پیش نظارہ";
$lang["audio"] = "آڈیو";
$lang["video"] = "ویڈیو";
$lang["clip"] ="کلپ";
$lang["music"] = "میوزک";
$lang["quality"] = "کوالٹی";
$lang["format"] = "فارمیٹ";
$lang["size"] = "سائز";
$lang["show-all"] = "تمام ویڈیوز دکھائیں";
$lang["coming-soon"] = "مزید جلد آرہے ہیں ...";
$lang["download-ready"] = "ڈاؤن لوڈ کے لئے تیار";
$lang["invalid-url"] = "URL غلط ہے";
$lang["error-alert"] = "نامعلوم خامی پیش آگئی۔";
$lang["try-again"] = "براہ کرم یو آر ایل چیک کریں اور دوبارہ کوشش کریں۔";
$lang["deleted-video"] = "اس ویڈیو کو حذف یا چھپا دیا گیا ہے۔";
$lang["placeholder"] = "ویڈیو URL پیسٹ کریں";
$lang["homepage-slogan"] = "مفت آن لائن ویڈیو ڈاؤنلوڈر";
$lang["multiple-sources"] = "متعدد ذرائع سے ویڈیوز ڈاؤن لوڈ کریں";
$lang["about"] = "ویڈیو ڈاؤنلوڈر اسکرپٹ آپ کو متعدد ذرائع سے MP4 ، M4A ، 3GP سمیت متعدد فارمیٹس میں ویڈیوز ڈاؤن لوڈ کرنے کی پیش کش کرتا ہے";
$lang["about-title"] = "مفت آن لائن ویڈیو ڈاؤنلوڈر";
$lang["sources-are-supported"] = "ذرائع کی حمایت کی جاتی ہے";
$lang["download-audios"] = "آڈیو ڈاؤن لوڈ کریں";
$lang["download-audios-from"] = "سے آڈیو ڈاؤن لوڈ کریں";
$lang["howto-download"] = "ڈاؤنلوڈ کیسے کریں";