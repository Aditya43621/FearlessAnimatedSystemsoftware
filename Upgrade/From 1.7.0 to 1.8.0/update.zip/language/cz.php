<?php
/*
 * Translate only right side.
 * Don't delete quotes and semicolon.
 */
$lang["404-not-found"] = "404 Stránka nenalezena";
$lang["go-home"] = "Přejít na domovskou stránku";
$lang["terms-of-service"] = "Podmínky služby";
$lang["contact"] = "Kontakt";
$lang["language"] = "Jazyk";
$lang["supported-sites"] = "Podporované webové stránky";
$lang["home"] = "Domů";
$lang["close"] = "Zavřít";
$lang["follow-us"] = "Sleduj nás";
$lang["share"] = "Sdílet";
$lang["download"] = "Stáhnout";
$lang["downloader"] = "Přehrávač";
$lang["downloads"] = "Stahování";
$lang["video-downloader"] = "Video přehrávač";
$lang["details"] = "Podrobnosti o videu";
$lang["duration"] = "Doba trvání";
$lang["preview"] = "Náhled";
$lang["audio"] = "Zvuk";
$lang["video"] = "Video";
$lang["video"] = "Další Video";
$lang["music"] = "Hudba";
$lang["clip"] = "Klip";
$lang["quality"] = "Kvalita";
$lang["format"] = "Formát";
$lang["size"] = "Velikost";
$lang["show-all"] = "Zobrazit všechna videa";
$lang["coming-soon"] = "Více již brzy...";
$lang["download-ready"] = "Připraveno ke stažení";
$lang["invalid-url"] = "Adresa URL je neplatná";
$lang["error-alert"] = "Došlo k neznámé chybě.";
$lang["try-again"] = "Zkontrolujte prosím URL a zkuste to znovu.";
$lang["deleted-video"] = "Toto video bylo smazáno nebo skryto.";
$lang["placeholder"] = "Vložte adresu URL videa z";
$lang["homepage-slogan"] = "Stahujte a přehrávejte videa z Youtube a dalších webů.";
$lang["multiple-sources"] = "Stahujte videa z více zdrojů";
$lang["about"] = "Online video přehrávač vám umožňuje stahovat videa v různých formátech včetně MP4, M4A, 3GP z více zdrojů, které zahrnují";
$lang["about-title"] = "Online video přehrávač zdarma";
$lang["sources-are-supported"] = "zdroje jsou podporovány";
$lang["download-audios"] = "Stáhněte si audio";
$lang["download-audios-from"] = "Stáhněte si audia z";
$lang["howto-download"] = "Jak stáhnout?";